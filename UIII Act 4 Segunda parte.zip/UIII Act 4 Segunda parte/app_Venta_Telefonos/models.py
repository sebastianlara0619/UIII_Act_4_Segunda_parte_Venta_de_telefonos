from django.db import models

# --- SECCIÓN 1: PROVEEDORES Y PRODUCTOS ---

class Proveedor(models.Model):
    nombre = models.CharField(max_length=100)
    empresa = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    # Quitamos 'unique=True' si existiera para evitar bloqueos en registros rápidos
    email = models.EmailField() 
    direccion = models.CharField(max_length=200)
    ciudad = models.CharField(max_length=100)
    fecha_registro = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} ({self.empresa})"

class Producto(models.Model):
    nombre = models.CharField(max_length=100)
    marca = models.CharField(max_length=50)
    modelo = models.CharField(max_length=50)
    precio_venta = models.DecimalField(max_digits=10, decimal_places=2)
    stock = models.PositiveIntegerField()
    descripcion = models.TextField(blank=True, null=True)
    fecha_ingreso = models.DateField(auto_now_add=True)
    # Mantenemos la relación ManyToMany
    proveedores = models.ManyToManyField(Proveedor, through='Producto_Proveedor', related_name='productos')

    def __str__(self):
        return f"{self.nombre} - {self.marca} ({self.modelo})"

class Producto_Proveedor(models.Model):
    producto = models.ForeignKey(Producto, on_delete=models.CASCADE, related_name='producto_proveedores')
    proveedor = models.ForeignKey(Proveedor, on_delete=models.CASCADE, related_name='productos_proveedor')
    precio_compra = models.DecimalField(max_digits=10, decimal_places=2)
    cantidad_disponible = models.PositiveIntegerField()
    garantia_meses = models.PositiveIntegerField(default=12)
    # CAMBIO CRÍTICO: Permitimos que sea nulo o auto-generado para que no truene el formulario
    fecha_entrega = models.DateField(auto_now_add=True) 
    lote = models.CharField(max_length=50, blank=True, null=True)

    def __str__(self):
        return f"{self.producto.marca} {self.producto.modelo} - {self.proveedor.empresa}"

# --- SECCIÓN 2: CLIENTES Y PERSONAL ---

class Cliente(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    tipo_cliente = models.CharField(
        max_length=50,
        choices=[
            ("Individual", "Individual"),
            ("Empresarial", "Empresarial"),
            ("Distribuidor", "Distribuidor"),
        ],
        default="Individual"
    )
    telefono = models.CharField(max_length=20)
    email = models.EmailField() # Recomendación: Quitar unique=True temporalmente si da errores de duplicados
    direccion = models.CharField(max_length=200)
    fecha_registro = models.DateField(auto_now_add=True)

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

class Vendedor(models.Model):
    nombre = models.CharField(max_length=100)
    apellido = models.CharField(max_length=100)
    cargo = models.CharField(max_length=100)
    telefono = models.CharField(max_length=20)
    email = models.EmailField()
    # CAMBIO: Permitir que se asigne hoy si no se envía dato
    fecha_contratacion = models.DateField(auto_now_add=True) 
    salario = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.nombre} {self.apellido} - {self.cargo}"

# --- SECCIÓN 3: VENTAS ---

class Venta(models.Model):
    folio = models.CharField(max_length=150)
    fecha_venta = models.DateField(auto_now_add=True)
    cliente = models.ForeignKey(Cliente, on_delete=models.CASCADE, related_name="compras")
    vendedor = models.ForeignKey(Vendedor, on_delete=models.SET_NULL, null=True, related_name="ventas_realizadas")
    productos = models.ManyToManyField(Producto, related_name="ventas")
    total_pago = models.DecimalField(max_digits=12, decimal_places=2)
    estado_pedido = models.CharField(
        max_length=50,
        choices=[
            ("Pendiente", "Pendiente"),
            ("Enviado", "Enviado"),
            ("Entregado", "Entregado"),
        ],
        default="Pendiente",
    )

    def __str__(self):
        return f"Venta {self.folio} - {self.cliente}"