from django.shortcuts import render, redirect, get_object_or_404
from .models import Vendedor, Proveedor, Producto, Venta, Producto_Proveedor
from django.utils import timezone

# --- SECCIÓN: INICIO ---
def inicio_ventas(request):
    """Página principal del sistema."""
    return render(request, 'inicio.html')

# --- SECCIÓN: VENDEDORES ---
def ver_vendedores(request):
    """Lista de todo el personal de ventas."""
    vendedores = Vendedor.objects.all()
    return render(request, 'vendedor/ver_vendedores.html', {'vendedores': vendedores})

def agregar_vendedor(request):
    """Registra un nuevo vendedor en la tienda."""
    if request.method == 'POST':
        Vendedor.objects.create(
            nombre=request.POST.get('nombre'),
            apellido=request.POST.get('apellido'),
            cargo=request.POST.get('cargo'),
            telefono=request.POST.get('telefono'),
            email=request.POST.get('email'),
            fecha_contratacion=request.POST.get('fecha_contratacion'),
            salario=request.POST.get('salario')
        )
        return redirect('ver_vendedores')
    return render(request, 'vendedor/agregar_vendedor.html')

def actualizar_vendedor(request, vendedor_id):
    """Modifica los datos de un vendedor existente."""
    vendedor = get_object_or_404(Vendedor, id=vendedor_id)
    if request.method == 'POST':
        vendedor.nombre = request.POST.get('nombre')
        vendedor.apellido = request.POST.get('apellido')
        vendedor.cargo = request.POST.get('cargo')
        vendedor.telefono = request.POST.get('telefono')
        vendedor.email = request.POST.get('email')
        vendedor.fecha_contratacion = request.POST.get('fecha_contratacion')
        vendedor.salario = request.POST.get('salario')
        vendedor.save()
        return redirect('ver_vendedores')
    return render(request, 'vendedor/actualizar_vendedor.html', {'vendedor': vendedor})

def borrar_vendedor(request, vendedor_id):
    """Elimina (da de baja) a un vendedor."""
    vendedor = get_object_or_404(Vendedor, id=vendedor_id)
    if request.method == 'POST':
        vendedor.delete()
        return redirect('ver_vendedores')
    return render(request, 'vendedor/borrar_vendedor.html', {'vendedor': vendedor})

# --- SECCIÓN: PROVEEDORES ---
def ver_proveedores(request):
    """Muestra el directorio de proveedores registrados."""
    proveedores = Proveedor.objects.all().order_by('-id') 
    return render(request, 'proveedor/ver_proveedor.html', {'proveedores': proveedores})

def agregar_proveedor(request):
    """Registra una nueva empresa proveedora de telefonía."""
    if request.method == 'POST':
        try:
            Proveedor.objects.create(
                nombre=request.POST.get('nombre'),
                empresa=request.POST.get('empresa'),
                telefono=request.POST.get('telefono'),
                email=request.POST.get('email'),
                direccion=request.POST.get('direccion'),
                ciudad=request.POST.get('ciudad')
            )
            return redirect('ver_proveedores')
        except Exception as e:
            print(f"ERROR AL GUARDAR PROVEEDOR: {e}")
            
    return render(request, 'proveedor/agregar_proveedor.html')

def actualizar_proveedor(request, proveedor_id):
    """Modifica los datos de un proveedor existente."""
    proveedor = get_object_or_404(Proveedor, id=proveedor_id)
    if request.method == 'POST':
        proveedor.nombre = request.POST.get('nombre')
        proveedor.empresa = request.POST.get('empresa')
        proveedor.telefono = request.POST.get('telefono')
        proveedor.email = request.POST.get('email')
        proveedor.direccion = request.POST.get('direccion')
        proveedor.ciudad = request.POST.get('ciudad')
        proveedor.save()
        return redirect('ver_proveedores')
    return render(request, 'proveedor/actualizar_proveedor.html', {'proveedor': proveedor})

def borrar_proveedor(request, proveedor_id):
    """Elimina un proveedor de la base de datos."""
    proveedor = get_object_or_404(Proveedor, id=proveedor_id)
    if request.method == 'POST':
        proveedor.delete()
        return redirect('ver_proveedores')
    return render(request, 'proveedor/borrar_proveedor.html', {'proveedor': proveedor})

# --- SECCIÓN: INVENTARIO / PRODUCTOS 
def ver_productos(request):
    """Muestra el stock de teléfonos disponibles."""
    productos = Producto.objects.all()
    return render(request, 'producto/ver_productos.html', {'productos': productos})