from django.urls import path
from . import views

urlpatterns = [
    path('', views.inicio_ventas, name='inicio_ventas'),
    
    # --- VENDEDORES ---
    path('vendedores/', views.ver_vendedores, name='ver_vendedores'),
    path('agregar_vendedor/', views.agregar_vendedor, name='agregar_vendedor'),
    path('actualizar_vendedor/<int:vendedor_id>/', views.actualizar_vendedor, name='actualizar_vendedor'),
    path('borrar_vendedor/<int:vendedor_id>/', views.borrar_vendedor, name='borrar_vendedor'),

    # --- PROVEEDORES ---
    path('proveedores/', views.ver_proveedores, name='ver_proveedores'),
    path('agregar_proveedor/', views.agregar_proveedor, name='agregar_proveedor'),
    # RUTAS FALTANTES:
    path('actualizar_proveedor/<int:proveedor_id>/', views.actualizar_proveedor, name='actualizar_proveedor'),
    path('borrar_proveedor/<int:proveedor_id>/', views.borrar_proveedor, name='borrar_proveedor'),
    
    # --- PRODUCTOS (Para cuando empecemos con el inventario) ---
    path('productos/', views.ver_productos, name='ver_productos'),
]